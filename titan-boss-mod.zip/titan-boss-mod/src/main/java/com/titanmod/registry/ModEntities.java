package com.titanmod.registry;

import com.titanmod.TitanMod;
import com.titanmod.entity.MysticDragon;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, TitanMod.MODID);

    public static final RegistryObject<EntityType<MysticDragon>> MYSTIC_DRAGON = ENTITIES.register("mystic_dragon",
            () -> EntityType.Builder.of(MysticDragon::new, MobCategory.MONSTER)
                    .sized(4.5F, 3.0F)
                    .fireImmune()
                    .clientTrackingRange(16)
                    .updateInterval(3)
                    .build("mystic_dragon"));
}
