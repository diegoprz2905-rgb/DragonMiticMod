package com.titanmod.registry;

import com.titanmod.TitanMod;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, TitanMod.MODID);

    public static final RegistryObject<Item> DRAGON_HEART = ITEMS.register("dragon_heart",
            () -> new Item(new Item.Properties().rarity(Rarity.EPIC).fireResistant()));

    public static final RegistryObject<Item> MYSTIC_DRAGON_SPAWN_EGG = ITEMS.register("mystic_dragon_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.MYSTIC_DRAGON, 0x0E0E12, 0xFF5A00, new Item.Properties()));
}
