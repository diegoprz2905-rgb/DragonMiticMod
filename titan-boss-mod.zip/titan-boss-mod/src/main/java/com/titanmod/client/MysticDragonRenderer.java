package com.titanmod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.titanmod.TitanMod;
import com.titanmod.entity.MysticDragon;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class MysticDragonRenderer extends MobRenderer<MysticDragon, MysticDragonModel> {

    private static final ResourceLocation TEXTURE =
            new ResourceLocation(TitanMod.MODID, "textures/entity/mystic_dragon.png");

    /** Escala del modelo: lo hace gigante (unos 19 bloques de envergadura). */
    private static final float SCALE = 2.5F;

    public MysticDragonRenderer(EntityRendererProvider.Context context) {
        super(context, new MysticDragonModel(context.bakeLayer(MysticDragonModel.LAYER)), 2.5F);
        this.addLayer(new MysticDragonGlowLayer(this));
    }

    @Override
    protected void scale(MysticDragon dragon, PoseStack poseStack, float partialTick) {
        poseStack.scale(SCALE, SCALE, SCALE);
    }

    @Override
    protected float getFlipDegrees(MysticDragon dragon) {
        return 0.0F;
    }

    @Override
    public ResourceLocation getTextureLocation(MysticDragon dragon) {
        return TEXTURE;
    }
}
