package com.titanmod.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.titanmod.TitanMod;
import com.titanmod.entity.MysticDragon;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Modelo del Dragon Mistico. Textura de 256x256:
 *  - y 0..120   : escamas negras (todas las piezas "solidas" usan texOffs(0,0))
 *  - y 120..136 : zona brillante (ojos)
 *  - y 150..256 : membrana de las alas
 */
public class MysticDragonModel extends EntityModel<MysticDragon> {

    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(TitanMod.MODID, "mystic_dragon"), "main");

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart neck1;
    private final ModelPart neck2;
    private final ModelPart head;
    private final ModelPart jaw;
    private final ModelPart armL;
    private final ModelPart foreL;
    private final ModelPart armR;
    private final ModelPart foreR;
    private final ModelPart tail1;
    private final ModelPart tail2;
    private final ModelPart tail3;
    private final ModelPart tail4;

    public MysticDragonModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.neck1 = body.getChild("neck1");
        this.neck2 = neck1.getChild("neck2");
        this.head = neck2.getChild("head");
        this.jaw = head.getChild("jaw");
        this.armL = body.getChild("arm_l");
        this.foreL = armL.getChild("fore_l");
        this.armR = body.getChild("arm_r");
        this.foreR = armR.getChild("fore_r");
        this.tail1 = body.getChild("tail1");
        this.tail2 = tail1.getChild("tail2");
        this.tail3 = tail2.getChild("tail3");
        this.tail4 = tail3.getChild("tail4");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        // ---- Cuerpo + espinas dorsales ----
        CubeListBuilder bodyCubes = CubeListBuilder.create()
                .texOffs(0, 0).addBox(-7.0F, -12.0F, -14.0F, 14.0F, 12.0F, 28.0F);
        for (int i = 0; i < 6; i++) {
            bodyCubes.texOffs(0, 0).addBox(-1.0F, -15.0F, -12.0F + i * 5.0F, 2.0F, 3.0F, 2.0F);
        }
        PartDefinition body = root.addOrReplaceChild("body", bodyCubes, PartPose.offset(0.0F, 20.0F, 0.0F));

        // ---- Patas recogidas ----
        body.addOrReplaceChild("leg_fl", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-2.0F, 0.0F, -2.0F, 4.0F, 9.0F, 4.0F),
                PartPose.offsetAndRotation(5.0F, -1.0F, -9.0F, 0.6F, 0.0F, 0.0F));
        body.addOrReplaceChild("leg_fr", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-2.0F, 0.0F, -2.0F, 4.0F, 9.0F, 4.0F),
                PartPose.offsetAndRotation(-5.0F, -1.0F, -9.0F, 0.6F, 0.0F, 0.0F));
        body.addOrReplaceChild("leg_hl", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-2.5F, 0.0F, -2.5F, 5.0F, 10.0F, 5.0F),
                PartPose.offsetAndRotation(5.5F, -2.0F, 9.0F, 0.9F, 0.0F, 0.0F));
        body.addOrReplaceChild("leg_hr", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-2.5F, 0.0F, -2.5F, 5.0F, 10.0F, 5.0F),
                PartPose.offsetAndRotation(-5.5F, -2.0F, 9.0F, 0.9F, 0.0F, 0.0F));

        // ---- Cuello y cabeza ----
        PartDefinition neck1 = body.addOrReplaceChild("neck1", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-4.0F, -4.0F, -10.0F, 8.0F, 8.0F, 10.0F),
                PartPose.offsetAndRotation(0.0F, -6.0F, -14.0F, -0.5F, 0.0F, 0.0F));
        PartDefinition neck2 = neck1.addOrReplaceChild("neck2", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-3.5F, -3.5F, -9.0F, 7.0F, 7.0F, 9.0F),
                PartPose.offsetAndRotation(0.0F, 0.0F, -10.0F, 0.3F, 0.0F, 0.0F));

        PartDefinition head = neck2.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-5.0F, -4.0F, -12.0F, 10.0F, 8.0F, 12.0F)
                .texOffs(0, 0).addBox(-3.5F, -2.0F, -19.0F, 7.0F, 5.0F, 7.0F)
                .texOffs(0, 0).addBox(-5.5F, -5.0F, -10.0F, 11.0F, 1.5F, 4.0F)
                .texOffs(0, 122).addBox(5.0F, -3.0F, -9.0F, 0.6F, 2.0F, 3.0F)
                .texOffs(0, 122).addBox(-5.6F, -3.0F, -9.0F, 0.6F, 2.0F, 3.0F),
                PartPose.offsetAndRotation(0.0F, 0.0F, -9.0F, 0.35F, 0.0F, 0.0F));

        head.addOrReplaceChild("jaw", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-4.0F, 0.0F, -18.0F, 8.0F, 2.0F, 17.0F),
                PartPose.offset(0.0F, 3.0F, -1.0F));
        head.addOrReplaceChild("horn_l", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-1.0F, -1.0F, 0.0F, 2.0F, 2.0F, 10.0F),
                PartPose.offsetAndRotation(3.5F, -4.0F, -2.0F, 0.5F, 0.25F, 0.0F));
        head.addOrReplaceChild("horn_r", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-1.0F, -1.0F, 0.0F, 2.0F, 2.0F, 10.0F),
                PartPose.offsetAndRotation(-3.5F, -4.0F, -2.0F, 0.5F, -0.25F, 0.0F));

        // ---- Alas izquierda (+x) ----
        PartDefinition armL = body.addOrReplaceChild("arm_l", CubeListBuilder.create()
                .texOffs(0, 0).addBox(0.0F, -2.0F, -2.0F, 26.0F, 4.0F, 4.0F)
                .texOffs(0, 0).addBox(8.0F, -1.0F, 0.0F, 1.5F, 1.5F, 24.0F)
                .texOffs(0, 0).addBox(18.0F, -1.0F, 0.0F, 1.5F, 1.5F, 22.0F),
                PartPose.offsetAndRotation(7.0F, -10.0F, -6.0F, 0.0F, 0.0F, -0.2F));
        armL.addOrReplaceChild("membrane_l", CubeListBuilder.create().texOffs(0, 150)
                .addBox(1.0F, 0.0F, -1.0F, 25.0F, 1.0F, 26.0F), PartPose.ZERO);
        PartDefinition foreL = armL.addOrReplaceChild("fore_l", CubeListBuilder.create()
                .texOffs(0, 0).addBox(0.0F, -1.5F, -1.5F, 30.0F, 3.0F, 3.0F)
                .texOffs(0, 0).addBox(6.0F, -1.0F, 0.0F, 1.5F, 1.5F, 20.0F)
                .texOffs(0, 0).addBox(16.0F, -1.0F, 0.0F, 1.5F, 1.5F, 18.0F)
                .texOffs(0, 0).addBox(26.0F, -1.0F, 0.0F, 1.5F, 1.5F, 14.0F)
                .texOffs(0, 0).addBox(29.0F, -1.5F, -4.0F, 2.0F, 3.0F, 5.0F),
                PartPose.offset(26.0F, 0.0F, 0.0F));
        foreL.addOrReplaceChild("membrane_fl", CubeListBuilder.create().texOffs(0, 190)
                .addBox(0.0F, 0.0F, -1.0F, 30.0F, 1.0F, 20.0F), PartPose.ZERO);

        // ---- Alas derecha (-x) ----
        PartDefinition armR = body.addOrReplaceChild("arm_r", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-26.0F, -2.0F, -2.0F, 26.0F, 4.0F, 4.0F)
                .texOffs(0, 0).addBox(-9.5F, -1.0F, 0.0F, 1.5F, 1.5F, 24.0F)
                .texOffs(0, 0).addBox(-19.5F, -1.0F, 0.0F, 1.5F, 1.5F, 22.0F),
                PartPose.offsetAndRotation(-7.0F, -10.0F, -6.0F, 0.0F, 0.0F, 0.2F));
        armR.addOrReplaceChild("membrane_r", CubeListBuilder.create().texOffs(0, 150)
                .addBox(-26.0F, 0.0F, -1.0F, 25.0F, 1.0F, 26.0F), PartPose.ZERO);
        PartDefinition foreR = armR.addOrReplaceChild("fore_r", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-30.0F, -1.5F, -1.5F, 30.0F, 3.0F, 3.0F)
                .texOffs(0, 0).addBox(-7.5F, -1.0F, 0.0F, 1.5F, 1.5F, 20.0F)
                .texOffs(0, 0).addBox(-17.5F, -1.0F, 0.0F, 1.5F, 1.5F, 18.0F)
                .texOffs(0, 0).addBox(-27.5F, -1.0F, 0.0F, 1.5F, 1.5F, 14.0F)
                .texOffs(0, 0).addBox(-31.0F, -1.5F, -4.0F, 2.0F, 3.0F, 5.0F),
                PartPose.offset(-26.0F, 0.0F, 0.0F));
        foreR.addOrReplaceChild("membrane_fr", CubeListBuilder.create().texOffs(0, 190)
                .addBox(-30.0F, 0.0F, -1.0F, 30.0F, 1.0F, 20.0F), PartPose.ZERO);

        // ---- Cola ----
        PartDefinition tail1 = body.addOrReplaceChild("tail1", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-5.0F, -4.0F, 0.0F, 10.0F, 8.0F, 12.0F)
                .texOffs(0, 0).addBox(-1.0F, -7.0F, 3.0F, 2.0F, 3.0F, 2.0F),
                PartPose.offset(0.0F, -4.0F, 14.0F));
        PartDefinition tail2 = tail1.addOrReplaceChild("tail2", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-4.0F, -3.0F, 0.0F, 8.0F, 6.0F, 12.0F)
                .texOffs(0, 0).addBox(-1.0F, -6.0F, 3.0F, 2.0F, 3.0F, 2.0F),
                PartPose.offset(0.0F, 0.0F, 12.0F));
        PartDefinition tail3 = tail2.addOrReplaceChild("tail3", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-3.0F, -2.5F, 0.0F, 6.0F, 5.0F, 12.0F),
                PartPose.offset(0.0F, 0.0F, 12.0F));
        tail3.addOrReplaceChild("tail4", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-2.0F, -2.0F, 0.0F, 4.0F, 4.0F, 12.0F)
                .texOffs(0, 0).addBox(-0.5F, -5.0F, 4.0F, 1.0F, 10.0F, 8.0F),
                PartPose.offset(0.0F, 0.0F, 12.0F));

        return LayerDefinition.create(mesh, 256, 256);
    }

    @Override
    public void setupAnim(MysticDragon dragon, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        // Aleteo
        float flap = Mth.sin(ageInTicks * 0.2F);
        armL.zRot = -0.25F - flap * 0.55F;
        armR.zRot = -armL.zRot;
        foreL.zRot = 0.2F - Mth.sin(ageInTicks * 0.2F - 0.8F) * 0.45F;
        foreR.zRot = -foreL.zRot;

        // Leve subida y bajada del cuerpo
        body.y = 20.0F + Mth.sin(ageInTicks * 0.2F + 0.5F) * 1.5F;

        // Cola ondulante
        float wave = ageInTicks * 0.1F;
        tail1.xRot = 0.05F + Mth.sin(ageInTicks * 0.2F - 0.4F) * 0.06F;
        tail1.yRot = Mth.sin(wave) * 0.12F;
        tail2.yRot = Mth.sin(wave - 0.7F) * 0.18F;
        tail3.yRot = Mth.sin(wave - 1.4F) * 0.22F;
        tail4.yRot = Mth.sin(wave - 2.1F) * 0.26F;

        // Cuello, cabeza y mandibula
        neck1.xRot = -0.5F;
        neck2.xRot = 0.3F;
        head.xRot = 0.35F + headPitch * ((float) Math.PI / 180.0F) * 0.5F;
        head.yRot = Mth.clamp(netHeadYaw * ((float) Math.PI / 180.0F), -0.6F, 0.6F);

        if (dragon.isBreathing()) {
            jaw.xRot = 0.75F + Mth.sin(ageInTicks * 1.5F) * 0.05F;
        } else {
            jaw.xRot = 0.08F;
        }
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight,
                               int packedOverlay, float red, float green, float blue, float alpha) {
        root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
