package com.titanmod.client;

import com.titanmod.TitanMod;
import com.titanmod.entity.MysticDragon;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.resources.ResourceLocation;

/** Dibuja las grietas de lava y los ojos con brillo propio, incluso de noche. */
public class MysticDragonGlowLayer extends EyesLayer<MysticDragon, MysticDragonModel> {

    private static final RenderType GLOW = RenderType.eyes(
            new ResourceLocation(TitanMod.MODID, "textures/entity/mystic_dragon_glow.png"));

    public MysticDragonGlowLayer(RenderLayerParent<MysticDragon, MysticDragonModel> parent) {
        super(parent);
    }

    @Override
    public RenderType renderType() {
        return GLOW;
    }
}
