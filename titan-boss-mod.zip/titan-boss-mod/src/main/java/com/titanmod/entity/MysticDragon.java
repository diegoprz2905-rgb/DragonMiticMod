package com.titanmod.entity;

import java.util.EnumSet;
import java.util.UUID;
import javax.annotation.Nullable;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.FlyingMob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.MoveControl;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Dragon Mistico: jefe volador gigante de escamas negras que escupe fuego.
 */
public class MysticDragon extends FlyingMob implements Enemy {

    private static final EntityDataAccessor<Boolean> DATA_BREATHING =
            SynchedEntityData.defineId(MysticDragon.class, EntityDataSerializers.BOOLEAN);

    private static final UUID ENRAGE_DAMAGE_ID = UUID.fromString("5d8a7a2e-6c1f-4b0a-9c55-3f1a2b7e9d10");
    private static final AttributeModifier ENRAGE_DAMAGE =
            new AttributeModifier(ENRAGE_DAMAGE_ID, "Dragon fury", 0.4D, AttributeModifier.Operation.MULTIPLY_BASE);

    private final ServerBossEvent bossEvent = new ServerBossEvent(
            this.getDisplayName(), BossEvent.BossBarColor.RED, BossEvent.BossBarOverlay.NOTCHED_10);

    private int breathCooldown = 100;
    private int biteCooldown = 0;

    public MysticDragon(EntityType<? extends MysticDragon> type, Level level) {
        super(type, level);
        this.xpReward = 500;
        this.moveControl = new DragonMoveControl(this);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 400.0D)
                .add(Attributes.ATTACK_DAMAGE, 18.0D)
                .add(Attributes.ATTACK_KNOCKBACK, 1.5D)
                .add(Attributes.FOLLOW_RANGE, 64.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.ARMOR, 10.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_BREATHING, false);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FireBreathGoal(this));
        this.goalSelector.addGoal(2, new DragonFlyGoal(this));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, Player.class, 10, false, false, null));
    }

    /** Si alguien lo golpea (por ejemplo con un arco desde lejos), pasa a ser su objetivo. */
    @Override
    public boolean hurt(DamageSource source, float amount) {
        boolean result = super.hurt(source, amount);
        if (result && this.getTarget() == null
                && source.getEntity() instanceof Player p && !p.isCreative() && !p.isSpectator()) {
            this.setTarget(p);
        }
        return result;
    }

    // ------------------------------------------------------------------
    // Estado
    // ------------------------------------------------------------------

    public boolean isBreathing() {
        return this.entityData.get(DATA_BREATHING);
    }

    private void setBreathing(boolean breathing) {
        this.entityData.set(DATA_BREATHING, breathing);
    }

    public boolean isEnraged() {
        return this.getHealth() <= this.getMaxHealth() * 0.5F;
    }

    // ------------------------------------------------------------------
    // Logica del servidor
    // ------------------------------------------------------------------

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();

        if (breathCooldown > 0) breathCooldown--;
        if (biteCooldown > 0) biteCooldown--;

        bossEvent.setProgress(this.getHealth() / this.getMaxHealth());

        if (isEnraged()) {
            AttributeInstance damage = this.getAttribute(Attributes.ATTACK_DAMAGE);
            if (damage != null && !damage.hasModifier(ENRAGE_DAMAGE)) {
                damage.addTransientModifier(ENRAGE_DAMAGE);
                bossEvent.setColor(BossEvent.BossBarColor.PURPLE);
                this.playSound(SoundEvents.ENDER_DRAGON_GROWL, 5.0F, 0.6F);
            }
        }

        LivingEntity target = this.getTarget();

        // Orientar el cuerpo hacia el objetivo, o hacia donde vuela.
        Vec3 look = target != null ? target.position().subtract(this.position()) : this.getDeltaMovement();
        if (look.horizontalDistanceSqr() > 0.04D) {
            float desired = (float) (Mth.atan2(look.z, look.x) * (180.0D / Math.PI)) - 90.0F;
            this.setYRot(Mth.approachDegrees(this.getYRot(), desired, 6.0F));
            this.yBodyRot = this.getYRot();
            this.yHeadRot = this.getYRot();
        }

        // Mordisco cuando el objetivo esta al alcance de la cabeza.
        if (target != null && target.isAlive() && biteCooldown <= 0 && this.distanceToSqr(target) < 72.0D) {
            this.doHurtTarget(target);
            biteCooldown = 30;
            this.playSound(SoundEvents.ENDER_DRAGON_GROWL, 3.0F, 1.1F);
        }

        // Si choca con algo, sube para destrabarse.
        if (this.horizontalCollision) {
            this.getMoveControl().setWantedPosition(this.getX(), this.getY() + 6.0D, this.getZ(), 1.0D);
        }

        if (this.tickCount % 24 == 0) {
            this.level().playSound(null, this.getX(), this.getY(), this.getZ(),
                    SoundEvents.ENDER_DRAGON_FLAP, SoundSource.HOSTILE, 4.0F, 0.85F);
        }
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide) {
            for (int i = 0; i < 2; i++) {
                this.level().addParticle(ParticleTypes.PORTAL,
                        this.getRandomX(3.0D), this.getRandomY(), this.getRandomZ(3.0D), 0.0D, 0.05D, 0.0D);
            }
            if (this.random.nextInt(3) == 0) {
                this.level().addParticle(ParticleTypes.FLAME,
                        this.getRandomX(2.0D), this.getY(0.6D), this.getRandomZ(2.0D), 0.0D, 0.02D, 0.0D);
            }
            if (this.isEnraged() && this.random.nextInt(2) == 0) {
                this.level().addParticle(ParticleTypes.LARGE_SMOKE,
                        this.getRandomX(2.5D), this.getRandomY(), this.getRandomZ(2.5D), 0.0D, 0.03D, 0.0D);
            }
        }
    }

    /** Un tick de aliento de fuego apuntando al objetivo. */
    private void breathFire(LivingEntity target, int ticks) {
        if (!(this.level() instanceof ServerLevel server)) return;

        Vec3 forward = Vec3.directionFromRotation(0.0F, this.getYRot());
        Vec3 mouth = this.position().add(forward.x * 7.2D, 2.4D, forward.z * 7.2D);
        Vec3 dir = target.getEyePosition().subtract(mouth).normalize();
        double reach = 26.0D;

        // Chorro de llamas
        for (int i = 0; i < 6; i++) {
            Vec3 d = dir.add(
                    (this.random.nextDouble() - 0.5D) * 0.16D,
                    (this.random.nextDouble() - 0.5D) * 0.16D,
                    (this.random.nextDouble() - 0.5D) * 0.16D).normalize();
            server.sendParticles(ParticleTypes.FLAME, mouth.x, mouth.y, mouth.z, 0, d.x, d.y, d.z, 0.9D);
        }
        server.sendParticles(ParticleTypes.LARGE_SMOKE, mouth.x, mouth.y, mouth.z, 0, dir.x, dir.y, dir.z, 0.5D);

        if (ticks % 4 == 0) {
            this.level().playSound(null, mouth.x, mouth.y, mouth.z,
                    SoundEvents.BLAZE_SHOOT, SoundSource.HOSTILE, 2.0F, 0.5F);
        }

        // Dano en forma de cono
        if (ticks % 5 == 0) {
            AABB box = new AABB(mouth, mouth.add(dir.scale(reach))).inflate(4.0D);
            for (LivingEntity e : this.level().getEntitiesOfClass(LivingEntity.class, box, this::canBurn)) {
                Vec3 rel = e.getBoundingBox().getCenter().subtract(mouth);
                double along = rel.dot(dir);
                if (along < 0.0D || along > reach) continue;
                double perp = rel.subtract(dir.scale(along)).length();
                if (perp <= 1.5D + along * 0.12D) {
                    e.setSecondsOnFire(8);
                    e.hurt(this.damageSources().mobAttack(this), 3.0F);
                }
            }
        }

        // Impacto contra el terreno: llamas y fuego
        if (ticks % 6 == 0) {
            BlockHitResult hit = this.level().clip(new ClipContext(
                    mouth, mouth.add(dir.scale(reach)), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, this));
            if (hit.getType() == HitResult.Type.BLOCK) {
                Vec3 p = hit.getLocation();
                server.sendParticles(ParticleTypes.FLAME, p.x, p.y, p.z, 14, 0.7D, 0.3D, 0.7D, 0.05D);
                server.sendParticles(ParticleTypes.LAVA, p.x, p.y, p.z, 4, 0.5D, 0.2D, 0.5D, 0.0D);

                if (ticks % 12 == 0 && this.level().getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) {
                    BlockPos firePos = hit.getBlockPos().relative(hit.getDirection());
                    tryIgnite(firePos);
                    for (int i = 0; i < 2; i++) {
                        tryIgnite(firePos.offset(this.random.nextInt(3) - 1, 0, this.random.nextInt(3) - 1));
                    }
                }
            }
        }
    }

    private void tryIgnite(BlockPos pos) {
        if (this.level().isEmptyBlock(pos)) {
            BlockState fire = BaseFireBlock.getState(this.level(), pos);
            if (fire.canSurvive(this.level(), pos)) {
                this.level().setBlockAndUpdate(pos, fire);
            }
        }
    }

    private boolean canBurn(LivingEntity e) {
        if (e == this || !e.isAlive() || e instanceof MysticDragon) return false;
        if (e instanceof Player p) return !p.isCreative() && !p.isSpectator();
        return !(e instanceof Enemy);
    }

    // ------------------------------------------------------------------
    // Barra de jefe
    // ------------------------------------------------------------------

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossEvent.removePlayer(player);
    }

    @Override
    public void setCustomName(@Nullable Component name) {
        super.setCustomName(name);
        bossEvent.setName(this.getDisplayName());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (this.hasCustomName()) {
            bossEvent.setName(this.getDisplayName());
        }
    }

    // ------------------------------------------------------------------
    // Ajustes varios
    // ------------------------------------------------------------------

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) {
        return false;
    }

    @Override
    public boolean isInvulnerableTo(DamageSource source) {
        return super.isInvulnerableTo(source) || source.is(DamageTypes.IN_WALL);
    }

    @Override
    public boolean isPushedByFluid() {
        return false;
    }

    /** Las alas sobresalen mucho de la hitbox: ampliamos la zona de culling para que no desaparezcan. */
    @Override
    public AABB getBoundingBoxForCulling() {
        return this.getBoundingBox().inflate(12.0D, 3.0D, 12.0D);
    }

    @Override
    public boolean canChangeDimensions() {
        return false;
    }

    @Override
    public SoundSource getSoundSource() {
        return SoundSource.HOSTILE;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENDER_DRAGON_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENDER_DRAGON_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENDER_DRAGON_DEATH;
    }

    @Override
    protected float getSoundVolume() {
        return 4.0F;
    }

    // ------------------------------------------------------------------
    // IA: movimiento y aliento
    // ------------------------------------------------------------------

    /** Control de movimiento para volar libremente en 3D. */
    static class DragonMoveControl extends MoveControl {
        private final MysticDragon dragon;

        DragonMoveControl(MysticDragon dragon) {
            super(dragon);
            this.dragon = dragon;
        }

        @Override
        public void tick() {
            if (this.operation != Operation.MOVE_TO) return;

            Vec3 delta = new Vec3(
                    this.wantedX - this.mob.getX(),
                    this.wantedY - this.mob.getY(),
                    this.wantedZ - this.mob.getZ());
            double dist = delta.length();

            if (dist < 2.0D) {
                this.operation = Operation.WAIT;
                this.mob.setDeltaMovement(this.mob.getDeltaMovement().scale(0.6D));
                return;
            }

            double accel = 0.045D * this.speedModifier * (dragon.isEnraged() ? 1.4D : 1.0D);
            this.mob.setDeltaMovement(this.mob.getDeltaMovement().add(delta.scale(accel / dist)));
        }
    }

    /** Vuela en circulos alrededor del objetivo, o patrulla a gran altura. */
    static class DragonFlyGoal extends Goal {
        private final MysticDragon dragon;

        DragonFlyGoal(MysticDragon dragon) {
            this.dragon = dragon;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            if (!dragon.getMoveControl().hasWanted()) return true;
            return dragon.random.nextInt(60) == 0;
        }

        @Override
        public boolean canContinueToUse() {
            return false;
        }

        @Override
        public void start() {
            RandomSource r = dragon.random;
            Level level = dragon.level();
            LivingEntity target = dragon.getTarget();

            double cx = target != null ? target.getX() : dragon.getX();
            double cz = target != null ? target.getZ() : dragon.getZ();
            double angle = r.nextDouble() * Math.PI * 2.0D;
            double radius = target != null ? 10.0D + r.nextDouble() * 10.0D : 8.0D + r.nextDouble() * 16.0D;
            double x = cx + Math.cos(angle) * radius;
            double z = cz + Math.sin(angle) * radius;

            if (!level.hasChunkAt(BlockPos.containing(x, dragon.getY(), z))) {
                x = dragon.getX();
                z = dragon.getZ();
            }

            int ground = level.getHeight(Heightmap.Types.MOTION_BLOCKING, Mth.floor(x), Mth.floor(z));
            double baseY = target != null ? Math.max(target.getY() + 7.0D, ground + 8.0D) : ground + 10.0D;
            double y = Math.min(baseY + r.nextInt(6), level.getMaxBuildHeight() - 6);

            dragon.getMoveControl().setWantedPosition(x, y, z, 1.0D);
        }
    }

    /** Escupe fuego durante unos segundos cuando ve a su objetivo. */
    static class FireBreathGoal extends Goal {
        private static final int DURATION = 60;

        private final MysticDragon dragon;
        private int ticks;

        FireBreathGoal(MysticDragon dragon) {
            this.dragon = dragon;
        }

        @Override
        public boolean canUse() {
            LivingEntity target = dragon.getTarget();
            return target != null
                    && target.isAlive()
                    && dragon.breathCooldown <= 0
                    && dragon.distanceToSqr(target) < 32.0D * 32.0D
                    && dragon.hasLineOfSight(target);
        }

        @Override
        public boolean canContinueToUse() {
            LivingEntity target = dragon.getTarget();
            return ticks < DURATION && target != null && target.isAlive();
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void start() {
            ticks = 0;
            dragon.setBreathing(true);
            dragon.playSound(SoundEvents.ENDER_DRAGON_GROWL, 5.0F, 0.8F);
        }

        @Override
        public void tick() {
            LivingEntity target = dragon.getTarget();
            if (target == null) return;
            ticks++;
            dragon.breathFire(target, ticks);
        }

        @Override
        public void stop() {
            dragon.setBreathing(false);
            dragon.breathCooldown = dragon.isEnraged() ? 60 : 120 + dragon.random.nextInt(60);
        }
    }
}
