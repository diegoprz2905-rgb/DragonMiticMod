package com.titanmod.event;

import com.titanmod.TitanMod;
import com.titanmod.entity.MysticDragon;
import com.titanmod.registry.ModEntities;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = TitanMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEvents {

    @SubscribeEvent
    public static void onAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.MYSTIC_DRAGON.get(), MysticDragon.createAttributes().build());
    }
}
