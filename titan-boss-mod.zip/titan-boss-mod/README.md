# Titan Boss Mod: Dragón Místico

Mod para **Minecraft Java 1.20.1** con **Forge 47.3.0** que agrega un dragón jefe.

## El Dragón Místico

- Dragón gigante de **escamas negras** con **alas enormes** (unos 19 bloques de envergadura).
- **Vuela** en círculos alrededor de su objetivo y patrulla a gran altura.
- **Escupe fuego**: un chorro en cono que quema a lo que toque y enciende bloques (si el gamerule `mobGriefing` está activo).
- **Muerde** a quien se acerque a su cabeza.
- **Barra de jefe** con 400 de vida (200 corazones).
- **Fase de furia** al bajar del 50 % de vida: vuela más rápido, escupe fuego más seguido, ataca con más fuerza y la barra se vuelve violeta.
- Inmune al fuego y a los empujones.
- Brilla en la oscuridad (ojos y grietas de lava) y deja partículas místicas.
- **Drops**: Corazón de Dragón Místico, 3-5 restos de netherita, 5-10 diamantes, 8-16 varas de blaze y 500 de experiencia.

## Cómo invocarlo

- Creativo: pestaña **Huevos generadores** → *Huevo generador de Dragón Místico*.
- Comando: `/summon titanmod:mystic_dragon`

> Consejo: probalo en un mundo de creativo primero. Si querés que sea más fácil o más difícil, cambiá la vida y el daño en `MysticDragon.createAttributes()`.

## Compilar con GitHub (sin instalar nada)

1. Creá una cuenta en [github.com](https://github.com) si no tenés.
2. Creá un repositorio nuevo (botón **New**), por ejemplo `titan-boss-mod`.
3. Subí **todo el contenido de esta carpeta** al repositorio. Lo más simple: en la página del repo, **Add file → Upload files** y arrastrá todo (incluida la carpeta oculta `.github`).
4. Entrá a la pestaña **Actions**. Va a aparecer el trabajo **Compilar mod** corriendo (tarda unos 5 a 10 minutos la primera vez).
5. Cuando termine con el tilde verde, abrí esa ejecución y bajá el archivo **titan-boss-mod-jar** de la sección *Artifacts*.
6. Descomprimí el ZIP descargado: adentro está el `.jar`.
7. Copiá el `.jar` a tu carpeta de mods: `%appdata%\.minecraft\mods` (Windows).

Si algún día querés recompilar, entrá a **Actions → Compilar mod → Run workflow**.

## Requisitos para jugarlo

- Minecraft Java **1.20.1**
- Forge **47.3.0** o superior (cualquier 47.x)

## Estructura

```
src/main/java/com/titanmod/
  TitanMod.java                 mod principal
  registry/                     registro de entidad e ítems
  entity/MysticDragon.java      el dragón (IA, aliento de fuego, furia, barra de jefe)
  client/                       modelo 3D, renderer, capa brillante
  event/ModEvents.java          atributos del dragón
src/main/resources/
  assets/titanmod/              texturas, modelos de ítems y traducciones
  data/titanmod/loot_tables/    drops del dragón
```
